from dotenv import load_dotenv
load_dotenv()
from flask import Flask, render_template, jsonify, request
from scraper import run_all_scrapers, send_to_discord_and_sms
from threading import Thread, Lock
import time
import json
import os

app = Flask(__name__)

# -------------------------------
# File Paths and Locks
# -------------------------------
DATA_FILE = "listings.json"
data_lock = Lock()

# -------------------------------
# Data Management (File-based)
# -------------------------------
def load_data():
    """Loads listings from a JSON file, or initializes with a default."""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return {
        "live": [],
        "rejected": [],
        "missing": [],
        "logs": [{"time": time.strftime("%Y-%m-%d %H:%M:%S"), "type": "init", "status": "✅ Loaded from file"}]
    }

def save_data(data):
    """Saves listings to a JSON file."""
    with open(DATA_FILE, "w") as f:
        json.dump(data, f)

# Initialize data store on startup
data_store = load_data()


# -------------------------------
# Core Scrape Logic
# -------------------------------
def perform_scrape(scrape_type):
    """
    Performs the scraping, updates data store, and handles logging.
    This function is thread-safe due to the lock.
    """
    log_entry = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "type": scrape_type}
    try:
        listings = run_all_scrapers()

        with data_lock:
            existing_urls = {car['link'] for car in data_store['live']}
            new_cars = [car for car in listings if car['link'] not in existing_urls]

            if new_cars:
                send_to_discord_and_sms(new_cars)
                for car in new_cars:
                    # Add new cars to the 'live' list with a new status property
                    data_store['live'].append({**car, 'status': 'live'})
                log_entry["status"] = f"✅ Found {len(new_cars)} new cars"
            else:
                log_entry["status"] = "⚠️ No new listings"
    except Exception as e:
        log_entry["status"] = f"❌ Error: {e}"

    with data_lock:
        data_store['logs'].append(log_entry)
        save_data(data_store) # Save changes after every scrape


# -------------------------------
# Routes
# -------------------------------
@app.route("/")
def index():
    with data_lock:
        # Combine all listings for display
        all_listings = data_store['live'] + data_store['rejected'] + data_store['missing']
        logs_to_display = data_store['logs'][-10:] # show only last 10 logs

    return render_template(
        "index.html",
        cars=all_listings,
        logs=logs_to_display
    )


@app.route("/api/cars")
def api_cars():
    with data_lock:
        return jsonify(data_store)


@app.route("/scrape", methods=["POST"])
def manual_scrape():
    """Manually trigger a scrape via browser/API"""
    Thread(target=perform_scrape, args=("manual",)).start()
    return jsonify({"status": "Scrape triggered. Check logs for progress."}), 202

@app.route("/save", methods=["POST"])
def save_state():
    """Saves the current state of listings from the frontend."""
    updated_data = request.json
    with data_lock:
        data_store['live'] = updated_data.get('live', [])
        data_store['rejected'] = updated_data.get('rejected', [])
        data_store['missing'] = updated_data.get('missing', [])
        save_data(data_store)
    return jsonify({"status": "State saved successfully"}), 200

# -------------------------------
# Background Scraper
# ------------------------------
def background_scraper():
    """Continuously scrapes every 5 minutes"""
    time.sleep(10)
    while True:
        perform_scrape("auto")
        time.sleep(300) # wait 5 minutes


# -------------------------------
# App Entry Point
# -------------------------------
if __name__ == "__main__":
    Thread(target=background_scraper, daemon=True).start()
    print("🚀 Flask app running at http://0.0.0.0:5000")
    app.run(host="0.0.0.0", port=5000)