#!/bin/bash
python discord_bot.py &
python app.py &
wait