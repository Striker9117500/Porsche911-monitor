from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from twilio.rest import Client
import requests
from seleniumbase import Driver

# -------------------------------
# Config
# -------------------------------
DISCORD_WEBHOOK = ""

TRIMS = {
    "Carrera GTS Coupe AWD", "Carrera GTS Coupe RWD",
    "Turbo Coupe AWD", "Turbo S Coupe AWD",
    "Carrera 4 GTS Coupe AWD", "Carrera S Turbo Coupe RWD",
    "Carrera Turbo Coupe", "Carrera Turbo Coupe RWD",
    "Turbo", "Turbo Coupe", "Turbo S", "Carrera GTS", "Carrera 4 GTS",
}
FEATURES = {"Sunroof / Moonroof", "Leather Seats"}
COLORS = {"Red", "Silver", "Grey", "White", "Unknown"}

# Twilio
TWILIO_SID = "MGfdc320f74f891af9faa761043fa1bd13"
TWILIO_AUTH = "127ab47e2ff64db40a0a91b3c80647a1e"
TWILIO_FROM = "+18777300509"
TWILIO_TO = "+16233098770"
client = Client(TWILIO_SID, TWILIO_AUTH)


# -------------------------------
# Selenium setup
# -------------------------------
def get_driver():
    driver = Driver(headless=True)
    return driver


# -------------------------------
# Site Scrapers
# -------------------------------
def scrape_cars_com(driver):
    print("Scraping Cars.com...")
    url = "https://www.cars.com/shopping/results/?makes[]=porsche&models[]=porsche-911&stock_type=used&list_price_min=80000&list_price_max=130000&year_min=2015&year_max=2023"
    driver.get(url)

    listings = []
    try:
        wait = WebDriverWait(driver, 10)
        cards = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".vehicle-card")))
        print(f"Cars.com: Found {len(cards)} raw cards.")
        for card in cards:
            try:
                title = card.find_element(By.CSS_SELECTOR, ".title").text
                price = card.find_element(By.CSS_SELECTOR, ".primary-price").text
                link = card.find_element(By.TAG_NAME, "a").get_attribute("href")
                image = card.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                details = card.text

                if not any(trim in title for trim in TRIMS):
                    continue
                if not any(color in details for color in COLORS):
                    continue

                listings.append({
                    "title": title, "price": price, "link": link,
                    "image": image, "details": details, "site": "Cars.com"
                })
            except Exception as e:
                continue
    except Exception as e:
        print(f"Cars.com: Failed to find listings. Error: {e}")

    print(f"Cars.com: Found {len(listings)} listings after filtering.")
    return listings


def scrape_autotrader(driver):
    print("Scraping Autotrader...")
    url = "https://www.autotrader.com/cars-for-sale/cars-between-80000-and-130000/sunroof/porsche/911/chandler-az?endYear=2023&extColorSimple=GRAY&extColorSimple=OFFWHITE&extColorSimple=RED&extColorSimple=SILVER&extColorSimple=WHITE&listingType=3P_CERT&listingType=CERTIFIED&listingType=USED&maximumSeating=4&searchRadius=0&startYear=2015&trimCode=911%7CCarrera%204%20GTS&trimCode=911%7CCarrera%20GTS&trimCode=911%7CTurbo%20S&zip=85224"
    driver.get(url)

    listings = []
    try:
        wait = WebDriverWait(driver, 10)
        # Updated CSS selector based on a more common structure
        cards = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.listing-card")))
        print(f"Autotrader: Found {len(cards)} raw cards.")
        for card in cards:
            try:
                title = card.find_element(By.CSS_SELECTOR, "h2").text
                price = card.find_element(By.CSS_SELECTOR, ".first-price").text
                link = card.find_element(By.TAG_NAME, "a").get_attribute("href")
                image = card.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                details = card.text

                listings.append({
                    "title": title, "price": price, "link": link,
                    "image": image, "details": details, "site": "Autotrader"
                })
            except Exception as e:
                continue
    except Exception as e:
        print(f"Autotrader: Failed to find listings. Error: {e}")

    print(f"Autotrader: Found {len(listings)} listings after filtering.")
    return listings


def scrape_cargurus(driver):
    print("Scraping CarGurus...")
    url = "https://www.cargurus.com/Cars/inventorylisting/viewDetailsFilterViewInventoryListing.action?colors=Gray&colors=Silver&colors=White&colors=Unknown&colors=Red&installedOptionIds=2&installedOptionIds=1&searchId=6f162849-e972-4636-8ae4-76cc3ec0f50d&distance=50&entitySelectingHelper.selectedEntity=d404&sourceContext=untrackedExternal_false_0&sortDir=ASC&sortType=BEST_MATCH&makeModelTrimPaths=m48&makeModelTrimPaths=m48%2Fd404&makeModelTrimPaths=m48%2Fd404%2FCarrera%204%20GTS%20Cabriolet%20AWD&makeModelTrimPaths=m48%2Fd404%2FCarrera%204%20GTS%20Coupe%20AWD&makeModelTrimPaths=m48%2Fd404%2FCarrera%20GTS%20Coupe%20AWD&makeModelTrimPaths=m48%2Fd404%2FCarrera%20GTS%20Coupe%20RWD&makeModelTrimPaths=m48%2Fd404%2FTurbo%20Coupe%20AWD&makeModelTrimPaths=m48%2Fd404%2FTurbo%20S%20Coupe%20AWD&srpVariation=DEFAULT_SEARCH&isDeliveryEnabled=true&nonShippableBaseline=0&startYear=2015&endYear=2023&maxAccidents=0&hideFrameDamaged=true&hideTheft=true&hideSalvage=true"
    driver.get(url)

    listings = []
    try:
        wait = WebDriverWait(driver, 10)
        cards = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div[data-cg-card]")))
        print(f"CarGurus: Found {len(cards)} raw cards.")
        for card in cards:
            try:
                title = card.find_element(By.CSS_SELECTOR, ".cg-listingTitle").text
                price = card.find_element(By.CSS_SELECTOR, ".cg-listingPrice").text
                link = card.find_element(By.TAG_NAME, "a").get_attribute("href")
                image = card.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                details = card.text

                listings.append({
                    "title": title, "price": price, "link": link,
                    "image": image, "details": details, "site": "CarGurus"
                })
            except Exception as e:
                continue
    except Exception as e:
        print(f"CarGurus: Failed to find listings. Error: {e}")

    print(f"CarGurus: Found {len(listings)} listings after filtering.")
    return listings


def scrape_carmax(driver):
    print("Scraping CarMax...")
    url = "https://www.carmax.com/cars/porsche/911/coupes/gray/silver/white/red?price=80000-130000"
    driver.get(url)

    listings = []
    try:
        wait = WebDriverWait(driver, 10)
        # Updated CSS selector based on inspection of the site
        cards = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div[data-testid='car-tile']")))
        print(f"CarMax: Found {len(cards)} raw cards.")
        for card in cards:
            try:
                title = card.find_element(By.CSS_SELECTOR, ".car-title").text
                price = card.find_element(By.CSS_SELECTOR, ".car-price").text
                link = card.find_element(By.TAG_NAME, "a").get_attribute("href")
                image = card.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                details = card.text

                listings.append({
                    "title": title, "price": price, "link": "https://carmax.com" + link,
                    "image": image, "details": details, "site": "CarMax"
                })
            except Exception as e:
                continue
    except Exception as e:
        print(f"CarMax: Failed to find listings. Error: {e}")

    print(f"CarMax: Found {len(listings)} listings after filtering.")
    return listings


def scrape_autotempest(driver):
    print("Scraping AutoTempest...")
    base_url = "https://www.autotempest.com/results?"
    all_autotempest_listings = []
    import urllib.parse

    for trim in TRIMS:
        search_params = {
            "make": "porsche", "model": "all911", "trim_kw": trim,
            "minprice": 80000, "maxprice": 130000,
            "minyear": 2015, "maxyear": 2023,
        }
        query_string = urllib.parse.urlencode(search_params)
        url = f"{base_url}{query_string}"

        driver.get(url)
        listings = []
        try:
            wait = WebDriverWait(driver, 10)
            cards = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".result")))
            print(f"AutoTempest: Found {len(cards)} raw cards for trim: {trim}.")

            for card in cards:
                try:
                    title = card.find_element(By.CSS_SELECTOR, ".result-title").text
                    price = card.find_element(By.CSS_SELECTOR, ".result-price").text
                    link = card.find_element(By.TAG_NAME, "a").get_attribute("href")
                    image = card.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                    details = card.text

                    listings.append({
                        "title": title, "price": price, "link": link,
                        "image": image, "details": details, "site": "AutoTempest"
                    })
                except Exception as e:
                    continue
        except Exception as e:
            print(f"AutoTempest: Failed to find listings for trim '{trim}'. Error: {e}")

        print(f"AutoTempest: Found {len(listings)} listings after filtering for trim: {trim}.")
        all_autotempest_listings.extend(listings)

    return all_autotempest_listings


# -------------------------------
# Main Runner
# -------------------------------
def run_all_scrapers():
    driver = get_driver()
    all_listings = []

    try:
        scrapers = [
            scrape_cars_com,
            scrape_autotrader,
            scrape_cargurus,
            scrape_carmax,
            scrape_porsche_cpo,
            scrape_edmunds,
            scrape_truecar,
            scrape_bat,
            scrape_carsandbids,
            scrape_carfax,
            scrape_pcarmarket,
            scrape_carsdirect,
            scrape_carsoup,
            scrape_ebaymotors,
        ]

        for scraper_func in scrapers:
            all_listings.extend(scraper_func(driver))

    finally:
        driver.quit()

    unique = {}
    for car in all_listings:
        if "link" in car and car["link"]:
            unique[car["link"]] = car

    return list(unique.values())


# -------------------------------
# Discord + SMS
# -------------------------------
def send_to_discord_and_sms(listings):
    for car in listings:
        message = {
            "embeds": [{
                "title": car["title"],
                "url": car["link"],
                "description": f"Price: {car['price']}\nSource: {car['site']}\nDetails: {car['details']}",
                "image": {"url": car["image"]}
            }]
        }
        try:
            r = requests.post(DISCORD_WEBHOOK, json=message)
            print("✅ Discord:", car["title"])
        except Exception as e:
            print("❌ Discord error:", e)

        msg = f"{car['site']} - {car['title']}\n{car['price']}\n{car['link']}"
        try:
            message = client.messages.create(
                body=msg, from_=TWILIO_FROM, to=TWILIO_TO
            )
            print("✅ SMS:", message.sid)
        except Exception as e:
            print("❌ SMS error:", e)


if __name__ == "__main__":
    cars = run_all_scrapers()
    print(f"\nFound {len(cars)} unique listings")
    send_to_discord_and_sms(cars)