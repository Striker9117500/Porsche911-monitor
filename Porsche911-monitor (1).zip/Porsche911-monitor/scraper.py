from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from twilio.rest import Client
import requests
from seleniumbase import Driver
import time

# -------------------------------
# Config
# -------------------------------
DISCORD_WEBHOOK = ""

TRIMS = {
    "Carrera GTS Coupe AWD", "Carrera GTS Coupe RWD",
    "Turbo Coupe AWD", "Turbo S Coupe AWD",
    "Carrera 4 GTS Coupe AWD", "Carrera S Turbo Coupe RWD",
    "Carrera Turbo Coupe", "Carrera Turbo Coupe RWD",
    "Turbo", "Turbo S", "Carrera GTS", "Carrera 4 GTS",
}
FEATURES = {"Sunroof / Moonroof", "Leather Seats"}
COLORS = {"Red", "Silver", "Grey", "White", "Unknown"}

# Twilio
TWILIO_SID = "MGfdc320f74f891af9faa761043fa1bd13"
TWILIO_AUTH = "127ab47e2ff64db40a0a91b3c80647a1e"
TWILIO_FROM = "+18777300509"
TWILIO_TO = "+16233098770"
client = Client(TWILIO_SID, TWILIO_AUTH)

# -------------------------------
# Selenium setup
# -------------------------------
def get_driver():
    driver = Driver(headless=True, uc=True)
    return driver

# -------------------------------
# Helpers
# -------------------------------
def get_element_text(container, selectors):
    for selector in selectors:
        try:
            element = container.find_element(By.CSS_SELECTOR, selector)
            if element and element.text.strip():
                return element.text.strip()
        except:
            continue
    return None

def get_element_attribute(container, selectors, attribute):
    for selector in selectors:
        try:
            element = container.find_element(By.CSS_SELECTOR, selector)
            if element:
                val = element.get_attribute(attribute)
                if val:
                    return val
        except:
            continue
    return None

# -------------------------------
# Scrapers
# -------------------------------
def scrape_cars_com(driver):
    print("Scraping Cars.com...")
    url = "https://www.cars.com/shopping/results/?include_shippable=true&makes[]=porsche&models[]=porsche-911&stock_type=used&year_min=2015&year_max=2023&list_price_min=80000&zip=85076"
    driver.get(url)
    listings = []
    try:
        wait = WebDriverWait(driver, 20)
        cards = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".vehicle-card")))
        print(f"Cars.com: Found {len(cards)} cards.")
        for card in cards:
            try:
                title = card.find_element(By.CSS_SELECTOR, ".title").text
                price = card.find_element(By.CSS_SELECTOR, ".primary-price").text
                link = card.find_element(By.TAG_NAME, "a").get_attribute("href")
                image = card.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
                details = card.text
                listings.append({"title": title, "price": price, "link": link, "image": image, "details": details, "site": "Cars.com"})
            except: continue
    except Exception as e:
        print("Cars.com error:", e)
    return listings

def scrape_autotrader(driver):
    print("Scraping Autotrader...")
    url = "https://www.autotrader.com/cars-for-sale/porsche/911?searchRadius=0&endYear=2023&startYear=2015&listingTypes=USED&zip=85224"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 15).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div[data-cmp='inventoryListing']")))
        print(f"Autotrader: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, ["h2", "h3", ".title"])
            price = get_element_text(card, [".first-price", ".price"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "Autotrader"})
    except Exception as e:
        print("Autotrader error:", e)
    return listings

def scrape_cargurus(driver):
    print("Scraping CarGurus...")
    url = "https://www.cargurus.com/Cars/inventorylisting/viewDetailsFilterViewInventoryListing.action?entitySelectingHelper.selectedEntity=d404&startYear=2015&endYear=2023&zip=85224"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 15).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div[data-testid='srp-tile-body']")))
        print(f"CarGurus: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, ["h4", ".listing-title"])
            price = get_element_text(card, [".price", ".cg-dealFinder-result-price"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "CarGurus"})
    except Exception as e:
        print("CarGurus error:", e)
    return listings

def scrape_carmax(driver):
    print("Scraping CarMax...")
    url = "https://www.carmax.com/cars/porsche/911/coupes?price=80000-130000"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 15).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".car-tile")))
        print(f"CarMax: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, [".car-title"])
            price = get_element_text(card, [".car-price"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            full_link = f"https://carmax.com{link}" if link and not link.startswith("http") else link
            listings.append({"title": title, "price": price, "link": full_link, "image": image, "details": card.text, "site": "CarMax"})
    except Exception as e:
        print("CarMax error:", e)
    return listings

# --- New Sites ---
def scrape_porsche(driver):
    print("Scraping Porsche Approved...")
    url = "https://finder.porsche.com/us/en-US/911/used"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.result-item")))
        print(f"Porsche Approved: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, [".model-description", ".title"])
            price = get_element_text(card, [".price"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "Porsche Approved"})
    except Exception as e:
        print("Porsche error:", e)
    return listings

def scrape_edmunds(driver):
    print("Scraping Edmunds...")
    url = "https://www.edmunds.com/used-porsche-911/"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".inventory-listing")))
        print(f"Edmunds: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, [".listing-title", "h2"])
            price = get_element_text(card, [".price"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "Edmunds"})
    except Exception as e:
        print("Edmunds error:", e)
    return listings

def scrape_truecar(driver):
    print("Scraping TrueCar...")
    url = "https://www.truecar.com/used-cars-for-sale/listings/porsche/911/"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.card-content")))
        print(f"TrueCar: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, ["h4", ".vehicle-card-title"])
            price = get_element_text(card, [".heading-3"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "TrueCar"})
    except Exception as e:
        print("TrueCar error:", e)
    return listings

def scrape_bringatrailer(driver):
    print("Scraping Bring a Trailer...")
    url = "https://bringatrailer.com/porsche/911/"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.listing-item")))
        print(f"Bring a Trailer: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, [".listing-title"])
            price = get_element_text(card, [".listing-bid"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "Bring a Trailer"})
    except Exception as e:
        print("BaT error:", e)
    return listings

def scrape_carsandbids(driver):
    print("Scraping Cars & Bids...")
    url = "https://carsandbids.com/search?q=Porsche%20911"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.auction-tile")))
        print(f"Cars & Bids: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, [".auction-title"])
            price = get_element_text(card, [".current-bid"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "Cars & Bids"})
    except Exception as e:
        print("Cars & Bids error:", e)
    return listings

def scrape_carfax(driver):
    print("Scraping Carfax...")
    url = "https://www.carfax.com/Used-Porsche-911_w5"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".srp-list-item")))
        print(f"Carfax: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, [".title"])
            price = get_element_text(card, [".srp-list-item-price"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "Carfax"})
    except Exception as e:
        print("Carfax error:", e)
    return listings

def scrape_pcarmarket(driver):
    print("Scraping PCARMARKET...")
    url = "https://www.pcarmarket.com/for-sale/?make=Porsche&model=911"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.auction-tile")))
        print(f"PCARMARKET: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, [".auction-title"])
            price = get_element_text(card, [".current-bid"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "PCARMARKET"})
    except Exception as e:
        print("PCARMARKET error:", e)
    return listings

def scrape_carsdirect(driver):
    print("Scraping CarsDirect...")
    url = "https://www.carsdirect.com/used_cars/listings/porsche/911"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".vehicle-card")))
        print(f"CarsDirect: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, [".title"])
            price = get_element_text(card, [".price"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "CarsDirect"})
    except Exception as e:
        print("CarsDirect error:", e)
    return listings

def scrape_carsoup(driver):
    print("Scraping CarSoup...")
    url = "https://www.carsoup.com/for-sale/Porsche/911/"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".vehicle-card")))
        print(f"CarSoup: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, [".vehicle-title"])
            price = get_element_text(card, [".price"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "CarSoup"})
    except Exception as e:
        print("CarSoup error:", e)
    return listings

def scrape_ebaymotors(driver):
    print("Scraping eBay Motors...")
    url = "https://www.ebay.com/sch/Cars-Trucks/6001/i.html?_nkw=Porsche+911&_sop=10"
    driver.get(url)
    listings = []
    try:
        cards = WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".s-item")))
        print(f"eBay Motors: Found {len(cards)} cards.")
        for card in cards:
            title = get_element_text(card, [".s-item__title"])
            price = get_element_text(card, [".s-item__price"])
            link = get_element_attribute(card, ["a"], "href")
            image = get_element_attribute(card, ["img"], "src")
            listings.append({"title": title, "price": price, "link": link, "image": image, "details": card.text, "site": "eBay Motors"})
    except Exception as e:
        print("eBay Motors error:", e)
    return listings

# -------------------------------
# Filtering
# -------------------------------
# -------------------------------
# Filtering
# -------------------------------
def filter_listings(all_listings):
    filtered_listings = []
    print(f"\nFiltering {len(all_listings)} total listings...")

    for car in all_listings:
        site = car.get("site", "")

        # Always include listings from Cars.com without filtering
        if site == "Cars.com":
            print(f"Including '{car.get('title')}' from Cars.com without filtering.")
            filtered_listings.append(car)
            continue # Move to the next car in the list

        # Apply filtering logic to all other sites
        title = car.get("title", "")
        details = car.get("details", "")
        price_str = "".join(filter(str.isdigit, car.get("price", "")))
        price = int(price_str) if price_str else None

        is_correct_trim = any(trim.lower() in title.lower() for trim in TRIMS)
        if not is_correct_trim:
            print(f"Skipping '{title}' from {site} due to incorrect trim.")
            continue

        has_feature = any(feature.lower() in details.lower() for feature in FEATURES)
        if not has_feature:
            print(f"Skipping '{title}' from {site} due to missing feature.")
            continue

        has_color = any(color.lower() in details.lower() for color in COLORS)
        if not has_color:
            print(f"Skipping '{title}' from {site} due to missing color.")
            continue

        is_valid_price = price and 80000 <= price <= 130000
        if not is_valid_price:
            print(f"Skipping '{title}' from {site} due to invalid price: {price}.")
            continue

        # If all conditions are met, add the car to the filtered list
        filtered_listings.append(car)
        print(f"Successfully added '{title}' to filtered list.")

    print(f"Filtering complete. Found {len(filtered_listings)} matching listings.")
    return filtered_listings

# -------------------------------
# Runner
# -------------------------------
def run_all_scrapers():
    driver = get_driver()
    all_listings = []

    scrapers = [
        scrape_cars_com, scrape_autotrader, scrape_cargurus, scrape_carmax,
        scrape_porsche, scrape_edmunds, scrape_truecar, scrape_bringatrailer,
        scrape_carsandbids, scrape_carfax, scrape_pcarmarket, scrape_carsdirect,
        scrape_carsoup, scrape_ebaymotors
    ]

    print("Starting all scrapers...")
    for scraper in scrapers:
        try:
            print(f"Running {scraper.__name__}...")
            listings = scraper(driver)
            all_listings.extend(listings)
            print(f"Successfully scraped {len(listings)} listings from {scraper.__name__}.")
        except Exception as e:
            print(f"Error in {scraper.__name__}: {e}")

    driver.quit()
    unique = {car["link"]: car for car in all_listings if car.get("link")}
    return list(unique.values())

# -------------------------------
# Discord + SMS
# -------------------------------
def send_to_discord_and_sms(listings):
    for car in listings:
        message = {"embeds": [{
            "title": car["title"], "url": car["link"],
            "description": f"Price: {car['price']}\nSource: {car['site']}\nDetails: {car['details']}",
            "image": {"url": car["image"]}
        }]}
        try:
            requests.post(DISCORD_WEBHOOK, json=message)
        except Exception as e: print("Discord error:", e)
        msg = f"{car['site']} - {car['title']}\n{car['price']}\n{car['link']}"