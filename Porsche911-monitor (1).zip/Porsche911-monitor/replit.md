# Overview

This is a Porsche 911 car listing monitor and scraper system that automatically searches for specific Porsche 911 models across automotive websites, filters results based on predefined criteria, and sends notifications via Discord webhooks and SMS. The system features a Flask web interface for real-time monitoring, a Discord bot for slash commands, and automated scraping with configurable parameters for price ranges, model years, trims, and features.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Flask Web Application**: Simple HTML template-based interface displaying live car listings
- **Real-time Dashboard**: Shows scraped car listings with images, prices, and details
- **Manual Scrape Trigger**: Web interface button for on-demand scraping
- **Activity Logging**: Visual log display showing scrape history and status

## Backend Architecture
- **Flask Server**: Main application server handling web requests and data management
- **Thread-safe Data Store**: In-memory storage with locking mechanism for concurrent access
- **Selenium-based Scraping**: Automated web scraping using SeleniumBase for headless browser automation
- **Configuration-driven Filtering**: JSON-based configuration for search parameters and criteria

## Data Storage Solutions
- **In-memory Data Store**: Thread-safe dictionary storing current car listings
- **JSON Configuration**: External config file for scraping parameters and API credentials
- **Log Storage**: In-memory activity logging with timestamp tracking

## Authentication and Authorization
- **Environment Variables**: Sensitive credentials stored in .env files
- **API Token Management**: Discord bot tokens and Twilio credentials externally configured
- **Webhook Authentication**: Discord webhook URLs for secure message delivery

## External Dependencies
- **Selenium WebDriver**: Browser automation for website scraping
- **Cars.com Integration**: Primary data source for Porsche 911 listings
- **Discord API**: Bot integration and webhook notifications
- **Twilio SMS Service**: SMS notification delivery system
- **Threading Support**: Concurrent scraping operations with lock-based synchronization

## Notification System
- **Multi-channel Alerts**: Combined Discord and SMS notifications for new listings
- **Webhook Integration**: Real-time Discord channel updates
- **SMS Gateway**: Twilio-powered text message notifications
- **Filtering Logic**: Automated matching against predefined criteria (trims, features, colors, price ranges)

## Scraping Architecture
- **Headless Browser Operation**: Selenium-based automated browsing
- **Error Handling**: Robust exception management with logging
- **Rate Limiting**: Controlled scraping frequency to avoid detection
- **Data Normalization**: Consistent formatting of scraped listing data

# External Dependencies

## Third-party Services
- **Cars.com**: Primary automotive listing data source
- **Discord API**: Bot commands and webhook notifications
- **Twilio**: SMS notification service

## Key Libraries and Frameworks
- **Flask**: Web application framework
- **SeleniumBase**: Enhanced Selenium wrapper for web scraping
- **Disnake**: Discord API library for bot functionality
- **BeautifulSoup4**: HTML parsing and data extraction
- **Requests**: HTTP client for API calls
- **python-dotenv**: Environment variable management

## Infrastructure Requirements
- **WebDriver Manager**: Automated browser driver management
- **Threading**: Concurrent operation support
- **JSON**: Configuration file format
- **Gunicorn**: Production WSGI server support