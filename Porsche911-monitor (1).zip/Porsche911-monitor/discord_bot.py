from dotenv import load_dotenv
load_dotenv()
import disnake
from disnake.ext import commands
import os, json
from scraper import run_all_scrapers


intents = disnake.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.slash_command(name="latest", description="Show latest Porsche 911 listings")
async def latest(ctx):
    cars = run_all_scrapers()
    if not cars:
        await ctx.respond("No cars found right now.")
    else:
        # Assuming the scraper returns a list of lists: [[year, title, price, url], ...]
        msg = "\n".join([f"{c[0]} {c[1]} - ${c[2]} ({c[3]})" for c in cars])
        await ctx.respond(msg)

bot.run(os.getenv("DISCORD_BOT_TOKEN"))